using System;
using MavenThought.Commons.Testing;

namespace $rootnamespace$
{
    /// <summary>
    /// Base specification for $sut$ 
    /// </summary>
    public abstract class $safeitemname$ 
        : AutoMockSpecificationWithNoContract<$sut$ >
    {
        /// <summary>
        /// Given these dependencies
        /// </summary>
        protected override void GivenThat()
        {
            base.GivenThat();
        }      
    }
}